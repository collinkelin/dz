<?php
namespace app\admin\model;

use think\Model;

class MerchantTotalModel extends Model{
	//表名
	protected $table = 'ly_merchant_total';
}