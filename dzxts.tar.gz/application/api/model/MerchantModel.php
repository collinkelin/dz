<?php
namespace app\api\model;

use think\Model;

class MerchantModel extends Model{
	//表名
	protected $table = 'ly_merchant';

	/**
	 * @return [type] [description]
	 */
	

}