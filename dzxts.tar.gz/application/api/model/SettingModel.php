<?php

/**
 * 编写：祝踏岚
 * 用于获取系统设置数据
 */

namespace app\api\model;

use think\Model;

class SettingModel extends Model{
	//表名
	protected $table = 'ly_setting';
}