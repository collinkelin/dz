<?php
namespace app\api\model;

use think\model;

class RecaivablesModel extends model{
	protected $table = 'ly_recaivables';

	
}
