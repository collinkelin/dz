<?php
namespace app\manage\model;

use think\Model;

class UserTeamModel extends Model{
	//表名
	protected $table = 'ly_user_team';
}