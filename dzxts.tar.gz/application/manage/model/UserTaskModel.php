<?php
namespace app\manage\model;

use think\Model;

class UserTaskModel extends Model{
	//表名
	protected $table = 'ly_user_task';

	/**
	 * 编辑订单
	 */
	public function edit(){
		
	}
}