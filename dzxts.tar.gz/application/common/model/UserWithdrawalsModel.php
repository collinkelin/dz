<?php
namespace app\common\model;

use think\Model;

class UserWithdrawalsModel extends Model{
	//表名
	protected $table = 'ly_user_withdrawals';


}