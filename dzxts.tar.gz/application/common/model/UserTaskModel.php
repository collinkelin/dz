<?php
namespace app\common\model;

use think\Model;

class UserTaskModel extends Model{
	//表名
	protected $table = 'ly_user_task';
}