<?php
namespace app\common\model;

use think\Model;

class MessageModel extends Model{
	
	protected $table = 'ly_message';

}