<?php
namespace app\common\model;

use think\Model;

class SlideModel extends Model{
	//表名
	protected $table = 'ly_slide';
}