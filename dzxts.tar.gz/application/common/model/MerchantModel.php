<?php
namespace app\common\model;

use think\Model;
/*
	A-阿大
	商户
*/

class MerchantModel extends Model{
	//表名
	protected $table = 'ly_merchant';

}